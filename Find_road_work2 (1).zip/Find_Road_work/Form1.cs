﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Find_Road_work
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormEditor editor = new FormEditor();
            editor.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "미로 불러오기";
            ofd.FileName = "*.kmaze";
            ofd.Filter = "미로 파일 (*.kmaze) | *.kmaze; | 모든 파일 (*.*) | *.*";

            DialogResult dr = ofd.ShowDialog();
            if (dr == DialogResult.OK)
            {
                string[] lines = File.ReadAllLines(ofd.FileName);

                FormEditor editor = new FormEditor(lines);
                editor.Show();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
                }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
