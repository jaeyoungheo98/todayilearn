﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace Find_Road_work
{
    class Node
    {
        public int x, y;
        public bool N, S, W, E;
        public Node previous = null;
        public bool filled = false;

        public Node(int _x, int _y, int ascii)
        {
            x = _x;
            y = _y;

            ascii -= 'A';

            if (ascii - 8 >= 0)
            {
                ascii -= 8;
                N = true;
            }
            if (ascii - 4 >= 0)
            {
                ascii -= 4;
                S = true;
            }
            if (ascii - 2 >= 0)
            {
                ascii -= 2;
                W = true;
            }
            if (ascii - 1 >= 0)
            {
                ascii -= 1;
                E = true;
            }
        }

        public Node(int _x, int _y)
        {
            x = _x;
            y = _y;
        }

        public override string ToString()
        {
            short result = 0;
            if (N) result += 8;
            if (S) result += 4;
            if (W) result += 2;
            if (E) result += 1;
            return ((char)('A' + result)).ToString();
        }

        public bool Passed()
        {
            return N || S || W || E;
        }

        public string GetPoint()
        {
            return x.ToString() + ',' + y.ToString();
        }

        public void DrawCenterPoint(Graphics graphics, Brush brush, float size)
        {
            float _x = x * size + size / 3;
            float _y = y * size + size / 3;
            graphics.FillEllipse(brush, _x, _y, size / 3, size / 3);
        }
    }
}
