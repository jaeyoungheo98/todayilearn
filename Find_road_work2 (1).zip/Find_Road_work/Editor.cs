﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace Find_Road_work
{
    public partial class FormEditor : Form
    {
        Random r = new Random();

        List<List<Node>> nodes;
        List<Node> history;

        Node start;
        Node end;

        private float WALL_SIZE = 0;
        private bool showingPath = false;

        public FormEditor()
        {
            InitializeComponent();
        }

        public FormEditor(string[] lines)
        {
            InitializeComponent();
            LoadMaze(lines);
        }

        private void LoadMaze(string[] lines)
        {
            width.Value = int.Parse(lines[0]);
            height.Value = int.Parse(lines[1]);

            string[] maze = lines[4..];

            if (width.Value > height.Value)
            {
                WALL_SIZE = (pictureBox1.Width) / (int)width.Value;
            }
            else
            {
                WALL_SIZE = (pictureBox1.Height) / (int)height.Value;
            }

            nodes = new List<List<Node>>();

            for (int x = 0; x < width.Value; x++)
            {
                nodes.Add(new List<Node>());
                for (int y = 0; y < height.Value; y++)
                {
                    nodes[x].Add(new Node(x, y, maze[x][y]));
                }
            }

            string[] start_coord = lines[2].Split(',');
            string[] end_coord = lines[3].Split(',');
            start = nodes[int.Parse(start_coord[0])][int.Parse(start_coord[1])];
            end = nodes[int.Parse(end_coord[0])][int.Parse(end_coord[1])];

            string[] path = lines[(4 + (int)width.Value)..];

            for (int x = 0; x < width.Value; x++)
            {
                string[] temp = path[x].Split('|');
                for (int y = 0; y < temp.Length; ++y)
                {
                    if (temp[y] != "null" && temp[y] != "")
                    {
                        string[] coords = temp[y].Split(',');
                        nodes[x][y].previous = nodes[int.Parse(coords[0])][int.Parse(coords[1])];
                    }
                }
            }
        }

        private void InitializeMaze()
        {
            start = null;
            end = null;
            nodes = new List<List<Node>>();

            if (width.Value > height.Value)
            {
                WALL_SIZE = (pictureBox1.Width) / (int)width.Value;
            }
            else
            {
                WALL_SIZE = (pictureBox1.Height) / (int)height.Value;
            }

            for (int x = 0; x < width.Value; x++)
            {
                nodes.Add(new List<Node>((int)height.Value));
                for (int y = 0; y < height.Value; y++)
                {
                    nodes[x].Add(new Node(x, y));
                }
            }

            history = new List<Node>();
            history.Add(nodes[r.Next(0, (int)width.Value)][r.Next(0, (int)height.Value)]);
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            if (WALL_SIZE != 0)
            {
                Graphics graphics = e.Graphics;

                float _x, _y;

                for (int x = 0; x < width.Value; x++)
                {
                    for (int y = 0; y < height.Value; y++)
                    {
                        _x = WALL_SIZE * x;
                        _y = WALL_SIZE * y;

                        if (nodes[x][y].filled)
                        {
                            graphics.FillRectangle(Brushes.SkyBlue, _x, _y, WALL_SIZE, WALL_SIZE);
                        }
                        if (!nodes[x][y].N)
                        {
                            graphics.DrawLine(Pens.Black, _x, _y, _x + WALL_SIZE, _y);
                        }
                        if (!nodes[x][y].S)
                        {
                            graphics.DrawLine(Pens.Black, _x, _y + WALL_SIZE, _x + WALL_SIZE, _y + WALL_SIZE);
                        }
                        if (!nodes[x][y].W)
                        {
                            graphics.DrawLine(Pens.Black, _x, _y, _x, _y + WALL_SIZE);
                        }
                        if (!nodes[x][y].E)
                        {
                            graphics.DrawLine(Pens.Black, _x + WALL_SIZE, _y, _x + WALL_SIZE, _y + WALL_SIZE);
                        }
                    }
                }

                if (start != null)
                {
                    start.DrawCenterPoint(e.Graphics, Brushes.Aquamarine, WALL_SIZE);
                }

                if (end != null)
                {
                    end.DrawCenterPoint(e.Graphics, Brushes.Orange, WALL_SIZE);
                }
            }
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (WALL_SIZE == 0)
            {
                return;
            }

            if (e.Button == MouseButtons.Right)
            {
                start = FindNode(e.Location);
            }
            else if (e.Button == MouseButtons.Left)
            {
                end = FindNode(e.Location);
            }

            pictureBox1.Refresh();
        }

        private Node FindNode(Point point)
        {
            int _x = (int)Math.Truncate(point.X / WALL_SIZE);

            if (_x >= (int)width.Value)
            {
                return null;
            }

            int _y = (int)Math.Truncate(point.Y / WALL_SIZE);

            if (_y >= (int)height.Value)
            {
                return null;
            }
            return nodes[_x][_y];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InitializeMaze();
            RecursiveBackTracking();
            pictureBox1.Refresh();
        }

        private void RecursiveBackTracking()
        {
            if (history.Count <= 0)
            {
                pictureBox1.Refresh();
                return;
            }

            Node current = history[history.Count - 1];
            Node? next = GetNearNode(current);

            if (next != null)
            {
                CheckNode(current, next);
            }
            else
            {
                history.RemoveAt(history.Count - 1);
            }

            RecursiveBackTracking();
        }

        private Node GetNearNode(Node node)
        {
            Node? N = GetNode(node.x, node.y + 1);
            Node? S = GetNode(node.x, node.y - 1);
            Node? W = GetNode(node.x - 1, node.y);
            Node? E = GetNode(node.x + 1, node.y);

            List<Node> nearNodes = new List<Node>();

            if (N != null && !N.Passed()) nearNodes.Add(N);
            if (S != null && !S.Passed()) nearNodes.Add(S);
            if (W != null && !W.Passed()) nearNodes.Add(W);
            if (E != null && !E.Passed()) nearNodes.Add(E);

            if (nearNodes.Count <= 0) return null;

            return nearNodes[r.Next(0, nearNodes.Count)];
        }

        private void CheckNode(Node current, Node nextNode)
        {
            if (current.x < nextNode.x)
            {
                current.E = true;
                nextNode.W = true;
            }

            if (current.x > nextNode.x)
            {
                current.W = true;
                nextNode.E = true;
            }

            if (current.y > nextNode.y)
            {
                current.N = true;
                nextNode.S = true;
            }

            if (current.y < nextNode.y)
            {
                current.S = true;
                nextNode.N = true;
            }

            history.Add(nextNode);
        }

        private Node GetNode(int x, int y)
        {
            if (0 <= x && x < width.Value && 0 <= y && y < height.Value)
            {
                return nodes[x][y];
            }
            return null;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (start == null || end == null)
            {
                MessageBox.Show("먼저 좌클릭과 우클릭으로 시작점과 도착점을 확정해주십시오.");
                return;
            }

            List<string> maze = new List<string>();
            string ppap = "";

            for (int x = 0; x < nodes.Count; x++)
            {
                string line = "";
                for (int y = 0; y < nodes[x].Count; y++)
                {
                    line += nodes[x][y];
                }
                maze.Add(line);
                ppap += line;
            }

            string fileName = GetMd5Hash(ppap + start.GetPoint() + end.GetPoint()) + ".maze";

            try
            {
                string[] lines = File.ReadAllLines(fileName);
                LoadMaze(lines);
                ShowPath();
            }
            catch (IOException)
            {
                PathFinder(start, end);
            }


            //Debug.WriteLine(ppap);
            //Debug.WriteLine(start.GetPoint());
            //Debug.WriteLine(end.GetPoint());

            using (StreamWriter outputFile = new StreamWriter(fileName))
            {
                outputFile.WriteLine(width.Value);
                outputFile.WriteLine(height.Value);

                outputFile.WriteLine(start.GetPoint());
                outputFile.WriteLine(end.GetPoint());

                foreach (string line in maze)
                {
                    outputFile.WriteLine(line);
                }

                for (int x = 0; x < nodes.Count; x++)
                {
                    string line = "";
                    for (int y = 0; y < nodes[x].Count; y++)
                    {
                        line += (nodes[x][y].previous == null ? "null" : nodes[x][y].previous.GetPoint()) + "|";
                    }
                    outputFile.WriteLine(line);
                }
            }

        }

        private void PathFinder(Node _start, Node _end)
        {
            Debug.WriteLine("ppapppapppappapapapa");
            List<Node> open = new List<Node>();
            List<Node> close = new List<Node>();
            Node current = null;
            int phase = 0;

            open.Add(start);

            FindPath();

            void FindPath()
            {
                ++phase;
                current = GetLowestNode();
            
                if (current == end)
                {
                    showingPath = true;
                    ShowPath();
                    showingPath = false;
                    return;
                }

                open.Remove(current);
                close.Add(current);

                if (current.N)
                {
                    Node temp = GetNode(current.x, current.y - 1);
                    if (temp != null && !close.Contains(temp))
                    {
                        temp.previous = current;
                        open.Add(temp);
                    }
                }
                if (current.S)
                {
                    Node temp = GetNode(current.x, current.y + 1);
                    if (temp != null && !close.Contains(temp))
                    {
                        temp.previous = current;
                        open.Add(temp);
                    }
                }
                if (current.W)
                {
                    Node temp = GetNode(current.x - 1, current.y);
                    if (temp != null && !close.Contains(temp))
                    {
                        temp.previous = current;
                        open.Add(temp);
                    }
                }
                if (current.E)
                {
                    Node temp = GetNode(current.x + 1, current.y);
                    if (temp != null && !close.Contains(temp))
                    {
                        temp.previous = current;
                        open.Add(temp);
                    }
                }

                pictureBox1.Refresh();

            
                FindPath();
            }

            Node GetLowestNode()
            {
                Node lowest = open[0];

                for (int i = 1; i < open.Count; i++)
                {
                    if (GetCost(lowest) > GetCost(open[i]))
                    {
                        lowest = open[i];
                    }
                }

                return lowest;
            }

            int GetCost(Node node)
            {
                return Math.Abs(end.x - node.x) * 10 + Math.Abs(end.y - node.y) * 10 + phase;
            }
        }

        private void ShowPath()
        {
            Node current = end;

            for (; current != start;)
            {
                current.filled = true;
                Node prev = current.previous;
                prev.filled = true;

                current = prev;

                pictureBox1.Refresh();
                Delay((int)delayTime.Value);
            }

            current = end;
            for (; current != start;)
            {
                current.filled = false;
                current.previous.filled = false;
                current = current.previous;
            }
        }

        private static DateTime Delay(int MS)
        {
            DateTime ThisMoment = DateTime.Now;
            TimeSpan duration = new TimeSpan(0, 0, 0, 0, MS);
            DateTime AfterWards = ThisMoment.Add(duration);

            while (AfterWards >= ThisMoment)
            {
                System.Windows.Forms.Application.DoEvents();
                ThisMoment = DateTime.Now;
            }

            return DateTime.Now;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (WALL_SIZE == 0)
            {
                MessageBox.Show("먼저 미로를 만들어주십시오.");
                return;
            }

            List<string> maze = new List<string>();
            string ppap = "";

            for (int x = 0; x < nodes.Count; x++)
            {
                string line = "";
                for (int y = 0; y < nodes[x].Count; y++)
                {
                    line += nodes[x][y];
                }
                maze.Add(line);
                ppap += line;
            }

            SaveFileDialog save = new SaveFileDialog();
            save.Title = "미로 저장하기";
            save.FileName = GetMd5Hash(ppap) + ".kmaze";
            save.Filter = "미로 파일 (*.kmaze) | *.kmaze; | 모든 파일 (*.*) | *.*";

            DialogResult dialogResult = save.ShowDialog();

            if (dialogResult == DialogResult.OK)
            {
                using (StreamWriter outputFile = new StreamWriter(save.FileName))
                {
                    foreach (string line in maze)
                    {
                        outputFile.WriteLine(line);
                    }
                }
                MessageBox.Show("성공적으로 저장되었습니다.");
            }

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
        
        }

        static string GetMd5Hash(string input)
        {
            MD5 mdHash = MD5.Create();
            byte[] data = mdHash.ComputeHash(Encoding.UTF8.GetBytes(input));

            StringBuilder sBuilder = new StringBuilder();

            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            return sBuilder.ToString();
        }

        private void FormEditor_Shown(object sender, EventArgs e)
        {
            ShowPath();
        }
    }
}